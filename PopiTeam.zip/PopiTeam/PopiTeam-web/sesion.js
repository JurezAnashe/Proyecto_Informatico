// =========================================================
// POPITEAM — Sesión de usuario y Carrito de compras
// Este archivo se incluye en todas las páginas del sitio.
// =========================================================

// Cuentas de prueba para poder iniciar sesión y probar el sitio
const CUENTAS_PRUEBA = [
    { correo: 'socio1@popiteam.com', contrasena: 'popiteam123', nombre: 'Lisandro' },
    { correo: 'socio2@popiteam.com', contrasena: 'popiteam123', nombre: 'Camila' },
    { correo: 'admin@popiteam.com',  contrasena: 'admin123',    nombre: 'Admin' }
];

const CLAVE_SESION = 'popiteam_sesion';
const CLAVE_CARRITO = 'popiteam_carrito';

// ---------------------------------------------------------
// Sesión de usuario
// ---------------------------------------------------------
function obtenerSesion() {
    try {
        return JSON.parse(localStorage.getItem(CLAVE_SESION));
    } catch (error) {
        return null;
    }
}

function iniciarSesion(correo, contrasena) {
    const cuenta = CUENTAS_PRUEBA.find(function (c) {
        return c.correo.toLowerCase() === correo.trim().toLowerCase() && c.contrasena === contrasena;
    });
    if (cuenta) {
        localStorage.setItem(CLAVE_SESION, JSON.stringify({ correo: cuenta.correo, nombre: cuenta.nombre }));
        return true;
    }
    return false;
}

function cerrarSesion() {
    localStorage.removeItem(CLAVE_SESION);
    actualizarBarraSuperior();
}

// Redirige a login.html si no hay sesión iniciada. Devuelve true si ya está logueado.
function requiereSesion(volverA) {
    if (!obtenerSesion()) {
        const pagina = volverA || window.location.pathname.split('/').pop();
        window.location.href = 'login.html?volver=' + encodeURIComponent(pagina);
        return false;
    }
    return true;
}

// ---------------------------------------------------------
// Carrito de compras
// ---------------------------------------------------------
function obtenerCarrito() {
    try {
        return JSON.parse(localStorage.getItem(CLAVE_CARRITO)) || [];
    } catch (error) {
        return [];
    }
}

function guardarCarrito(carrito) {
    localStorage.setItem(CLAVE_CARRITO, JSON.stringify(carrito));
    actualizarBarraSuperior();
}

function agregarAlCarrito(producto) {
    const carrito = obtenerCarrito();
    const existente = carrito.find(function (p) { return p.id === producto.id; });
    if (existente) {
        existente.cantidad += 1;
    } else {
        producto.cantidad = 1;
        carrito.push(producto);
    }
    guardarCarrito(carrito);
    mostrarAvisoCarrito(producto.nombre);
    if (typeof renderizarCarrito === 'function') renderizarCarrito();
}

function cambiarCantidadCarrito(id, cantidad) {
    cantidad = parseInt(cantidad, 10);
    if (isNaN(cantidad) || cantidad < 1) cantidad = 1;
    const carrito = obtenerCarrito().map(function (p) {
        if (p.id === id) p.cantidad = cantidad;
        return p;
    });
    guardarCarrito(carrito);
    if (typeof renderizarCarrito === 'function') renderizarCarrito();
}

function quitarDelCarrito(id) {
    const carrito = obtenerCarrito().filter(function (p) { return p.id !== id; });
    guardarCarrito(carrito);
    if (typeof renderizarCarrito === 'function') renderizarCarrito();
}

function vaciarCarrito() {
    guardarCarrito([]);
    if (typeof renderizarCarrito === 'function') renderizarCarrito();
}

function calcularTotalCarrito() {
    return obtenerCarrito().reduce(function (total, p) { return total + p.precio * p.cantidad; }, 0);
}

function calcularCantidadCarrito() {
    return obtenerCarrito().reduce(function (total, p) { return total + p.cantidad; }, 0);
}

// ---------------------------------------------------------
// Interfaz común: contador del carrito y estado de sesión en la barra superior
// ---------------------------------------------------------
function actualizarBarraSuperior() {
    document.querySelectorAll('.icono.carrito span').forEach(function (span) {
        span.textContent = calcularCantidadCarrito();
    });

    const sesion = obtenerSesion();
    document.querySelectorAll('.acciones-usuario__texto').forEach(function (enlace) {
        if (sesion) {
            enlace.textContent = 'Hola, ' + sesion.nombre + ' — Cerrar sesión';
            enlace.href = '#';
            enlace.onclick = function (e) {
                e.preventDefault();
                cerrarSesion();
                window.location.reload();
            };
        } else {
            enlace.textContent = 'Iniciar sesión o registrarse';
            enlace.href = 'login.html';
            enlace.onclick = null;
        }
    });
}

// Pequeño aviso flotante cuando se agrega un producto al carrito
function mostrarAvisoCarrito(nombreProducto) {
    let aviso = document.getElementById('avisoCarrito');
    if (!aviso) {
        aviso = document.createElement('div');
        aviso.id = 'avisoCarrito';
        aviso.style.cssText = 'position:fixed;bottom:24px;right:24px;background:#241609;color:#ffd200;padding:14px 22px;border-radius:10px;font-weight:700;font-size:.9rem;z-index:5000;box-shadow:0 12px 30px rgba(0,0,0,.35);transition:opacity .3s ease;opacity:0;';
        document.body.appendChild(aviso);
    }
    aviso.textContent = nombreProducto + ' se agregó al carrito 🛒';
    aviso.style.opacity = '1';
    clearTimeout(aviso._temporizador);
    aviso._temporizador = setTimeout(function () { aviso.style.opacity = '0'; }, 2200);
}

document.addEventListener('DOMContentLoaded', actualizarBarraSuperior);
