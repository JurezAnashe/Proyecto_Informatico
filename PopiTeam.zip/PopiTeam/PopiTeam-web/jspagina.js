// Función para abrir el recuadro del jugador y asignarle los datos básicos correspondientes
function abrirVentana(nombre, apellido, edad, posicion, valor, dorsal, descripcion) {
    // Unimos el nombre y el apellido en el título
    document.getElementById("ventana-nombre").innerText = nombre + " " + apellido;
    
    // Asignamos la información real a cada campo
    document.getElementById("ventana-dorsal").innerText = dorsal;
    document.getElementById("ventana-posicion").innerText = posicion;
    document.getElementById("ventana-edad").innerText = edad;
    document.getElementById("ventana-valor").innerText = valor;
    
    // Ocultamos la descripción del jugador
    let modalDesc = document.getElementById("ventana-descripcion");
    if (modalDesc) {
        modalDesc.style.display = "none";
    }

    // Buscamos en la lista el texto de "Club Actual" y lo forzamos a "Popiteam FC"
    let listaDatos = document.querySelectorAll(".lista-datos li");
    listaDatos.forEach(function(li) {
        if (li.innerText.includes("Club Actual")) {
            li.innerHTML = "<strong>Club Actual:</strong> Popiteam FC";
        }
    });
    
    // Muestra el recuadro cambiando el estilo display
    document.getElementById("ventanaJugador").style.display = "block";
}

// Función para cerrar el recuadro
function cerrarVentana() {
    document.getElementById("ventanaJugador").style.display = "none";
}

// Cierra automáticamente el recuadro si el usuario hace clic en el fondo oscuro exterior
window.onclick = function(event) {
    let ventana = document.getElementById("ventanaJugador");
    if (event.target == ventana) {
        ventana.style.display = "none";
    }
}