// Función para abrir el recuadro del jugador y asignarle los datos básicos correspondientes
function abrirModal(nombre, dorsal, posicion) {
    document.getElementById("modal-nombre").innerText = nombre;
    document.getElementById("modal-dorsal").innerText = dorsal;
    document.getElementById("modal-posicion").innerText = posicion;
    
    // Muestra el recuadro cambiando el estilo display
    document.getElementById("modalJugador").style.display = "block";
}

// Función para cerrar el recuadro
function cerrarModal() {
    document.getElementById("modalJugador").style.display = "none";
}

// Cierra automáticamente el recuadro si el usuario hace clic en el fondo oscuro exterior
window.onclick = function(event) {
    let modal = document.getElementById("modalJugador");
    if (event.target == modal) {
        modal.style.display = "none";
    }
}